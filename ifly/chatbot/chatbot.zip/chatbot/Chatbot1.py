import streamlit as st
import SparkApi

# 以下密钥信息从控制台获取，这里仅为示例，你需要使用真实的密钥
appid = "e97d3136"
api_secret = "MDExMGZmZjFjMzRhOTkzNzczMGEyMzgw"
api_key = "b25338415789cf13a0091d64a1b3381e"
domain = "generalv2"
Spark_url = "ws://spark-api.xf-yun.com/v2.1/chat"
text = []
if 'history_chats' not in st.session_state:
    st.session_state['history_chats'] = ["Chat1"]
if 'current_chat_index' not in st.session_state:
    st.session_state['current_chat_index'] = 0
if 'next_chat_number' not in st.session_state:
    st.session_state['next_chat_number'] = 2
if 'chat_contents' not in st.session_state:
    st.session_state['chat_contents'] = {"Chat1": []}
if 'messages' not in st.session_state:
    st.session_state['messages'] = []

def create_chat_fun():
    # 保存当前会话的内容
    current_chat_id = st.session_state['history_chats'][st.session_state['current_chat_index']]
    st.session_state['chat_contents'][current_chat_id] = st.session_state["messages"]
    
    # 创建新的会话ID，如Chat2, Chat3等
    new_chat = f"Chat{st.session_state['next_chat_number']}"
    st.session_state['history_chats'].append(new_chat)
    st.session_state['chat_contents'][new_chat] = []  # 初始化新聊天的内容
    st.session_state['current_chat_index'] = len(st.session_state['history_chats']) - 1
    st.session_state['next_chat_number'] += 1

    st.experimental_rerun()  # 重新运行以刷新侧边栏和主内容

def delete_chat_fun():
    # 检查索引是否在范围内
    if st.session_state['current_chat_index'] >= len(st.session_state['history_chats']) or st.session_state['current_chat_index'] < 0:
        st.session_state['current_chat_index'] = len(st.session_state['history_chats']) - 1

    # 使用try-except避免超出范围的错误
    try:
        del_chat = st.session_state['history_chats'][st.session_state['current_chat_index']]
        del st.session_state['chat_contents'][del_chat]
        st.session_state['history_chats'].remove(del_chat)
    except IndexError:
        st.error("There was an issue deleting the chat. Please try again.")

role_contexts = {
    '默认': '',
    '心理医生': '你是一位心理老师。今天你的任务是根据我的经历和感兴趣的内容围绕心理健康的重要性和影响因素等与心理健康相关的问题进行持续不断的讨论，若对同一问题多次提问后，答复仍旧不完整，则可以适当给出建议，相同问题最多问三遍。你要记住你是我的心理老师，你的每句话需要以一个简答题问句结尾来保证话题能够进行下去，非强制因素问答不能停止。这些问题需要设计得让我用一段话来回答，以达到锻炼我的发言能力的目的。这些问题包括但不限于心理状况、心理健康的重要性、影响因素、影响力、维持心理健康的方法和当代人心理健康状况等等。'
}


with st.sidebar:
    "[View the source code](https://github.com/streamlit/llm-examples/blob/main/Chatbot.py)"
    "[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/streamlit/llm-examples?quickstart=1)"

with st.container():
    selected_role = st.selectbox(
        'Which role would you like for the Spark model?',
        ('默认', '心理医生', 'Other')
    )
    st.title("💬 心理医生")
    audio_file = open('demo.wav', 'rb')
    audio_bytes = audio_file.read()

    # 使用st.audio函数播放音频
    st.audio(audio_bytes, format='audio/wav')

    # if "messages" not in st.session_state:
    #     st.session_state["messages"] = [{"role": "assistant", "content": "How can I help you?"}]

    if selected_role in role_contexts and role_contexts[selected_role]:
        context_message = [{
            "role": "user",
            "content": role_contexts[selected_role]
        }]
        # st.session_state.messages.append(context_message)
        # st.chat_message(context_message["role"]).write(context_message["content"])

        # 使用Spark模型获取回答
        SparkApi.answer = ""
        SparkApi.main(appid, api_key, api_secret, Spark_url, domain, context_message)
        response_content = SparkApi.answer

        # 将Spark模型的答案添加到聊天中
        response_message = {"role": "assistant", "content": response_content}
        print(response_content)
        # st.session_state.messages.append(response_message)
        st.chat_message(response_message["role"]).write(response_message["content"])

    for msg in st.session_state.messages:
        st.chat_message(msg["role"]).write(msg["content"])

    if prompt := st.chat_input():
        st.session_state.messages.append({"role": "user", "content": prompt})
        st.chat_message("user").write(prompt)

        # 使用Spark模型获取回答
        SparkApi.answer = ""
        SparkApi.main(appid, api_key, api_secret, Spark_url, domain, st.session_state.messages)
        response_content = SparkApi.answer

        # 将Spark模型的答案添加到聊天中
        st.session_state.messages.append({"role": "assistant", "content": response_content})
        st.chat_message("assistant").write(response_content)

