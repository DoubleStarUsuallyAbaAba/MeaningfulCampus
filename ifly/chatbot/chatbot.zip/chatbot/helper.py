import wave
import os
from tts import TTS
import streamlit as st
def pcm2wav(pcmname):
    pcmfile=open(pcmname,'rb')
    pcmdata = pcmfile.read()
    with wave.open(pcmname[:-4] + '.wav', 'wb') as wavfile:
        wavfile.setparams((1, 2, 16000, 0, 'NONE', 'NONE'))
        wavfile.writeframes(pcmdata)

def putwav(wavpath):
    audio_file = open(wavpath, 'rb')
    audio_bytes = audio_file.read()


    # # 使用st.audio函数播放音频
    # st.audio(audio_bytes, format='audio/ogg',auto_play=True, controls=False)
    st.audio(audio_bytes, format='audio/wav')

# pcm2wav('demo.pcm')
