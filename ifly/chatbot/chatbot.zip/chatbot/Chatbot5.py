import streamlit as st
import SparkApi
from helper import pcm2wav
from tts import TTS
from helper import putwav
from playsound import playsound
import threading
from virtualman import virtual_main
from machine_translation_python import En2Cn, Cn2En

# -- lzh
import time
import pyaudio
from rtasr import RTASR_Client
from difflib import SequenceMatcher
# -- lzh

# --wzx
import pandas as pd
import math
import plotly.express as px
from ise_ws_python3_demo import eval, interpolate_to_common_length
# --wzx
def chatworker():
    pass

def ttsworker(audio_path):
    audio_name = audio_path.split('.')[0]
    pcm_path = audio_name + '.pcm'

def get_model_content():
    return st.session_state.messages[0]["content"]


# 以下密钥信息从控制台获取，这里仅为示例，你需要使用真实的密钥
appid = "e97d3136"
api_secret = "MDExMGZmZjFjMzRhOTkzNzczMGEyMzgw"
api_key = "b25338415789cf13a0091d64a1b3381e"
domain = "generalv2"
Spark_url = "ws://spark-api.xf-yun.com/v2.1/chat"

# -- lzh -- start
# 初始化标点符号列表和存储数据的变量
stop_words = [',' , '.', '?' , '!' , ';', '，' , '。', '？' , '：', '！' , '；']  # 常见的标点符号
similarity_th = 0.4
# 创建一个Event对象
stop_event = False
# -- lzh -- end

if "initial_settings" not in st.session_state:
    # -- lzh -- start
    st.session_state["messages"] = []
    st.session_state.recognition = ""
    st.session_state.rtasr_frames = []
    st.session_state.recording = False
    st.session_state.submit = False
    st.session_state.first_time = True
    # -- lzh -- end
    st.session_state['history_chats'] = ["Chat1"]
    st.session_state['current_chat_index'] = 0
    st.session_state['next_chat_number'] = 2
    st.session_state['chat_contents'] = {"Chat1": []}
    # 设置完成
    st.session_state["initial_settings"] = True


#--zcl --start
def create_chat_fun():
    # 保存当前会话的内容
    current_chat_id = st.session_state['history_chats'][st.session_state['current_chat_index']]
    st.session_state['chat_contents'][current_chat_id] = st.session_state["messages"]
    
    # 创建新的会话ID，如Chat2, Chat3等
    new_chat = f"Chat{st.session_state['next_chat_number']}"
    st.session_state['history_chats'].append(new_chat)
    st.session_state['chat_contents'][new_chat] = []  # 初始化新聊天的内容
    st.session_state['current_chat_index'] = len(st.session_state['history_chats']) - 1
    st.session_state['next_chat_number'] += 1

    st.experimental_rerun()  # 重新运行以刷新侧边栏和主内容

def delete_chat_fun():
    # 如果没有其他聊天，就什么也不做
    if len(st.session_state['history_chats']) <= 1:
        return
    
    # 删除当前聊天
    del_chat = st.session_state['history_chats'][st.session_state['current_chat_index']]
    del st.session_state['chat_contents'][del_chat]
    st.session_state['history_chats'].remove(del_chat)

    # 更新当前聊天索引
    if st.session_state['current_chat_index'] >= len(st.session_state['history_chats']):
        st.session_state['current_chat_index'] = len(st.session_state['history_chats']) - 1

    st.experimental_rerun()  # 重新运行以刷新侧边栏和主内容
#-- zcl --end

# -- lzh -- start
# 更新字符串的函数
def update_dynamic_text():
    # 设置录音参数
    SAMPLE_RATE = 16000
    CHUNK_SIZE = 1280
    FORMAT = pyaudio.paInt16
    CHANNELS = 1

    client = RTASR_Client()
    audio = pyaudio.PyAudio()
    stream = audio.open(format=FORMAT, channels=CHANNELS, rate=SAMPLE_RATE, input=True, frames_per_buffer=CHUNK_SIZE)

    # 定义函数来计算字符串的重合度
    def similarity(a, b):
        return SequenceMatcher(None, a, b).ratio()

    try:
        text_placeholder = st.empty()
        all_input = ""
        last_input = ""
        while not stop_event:
            audio_chunk = stream.read(CHUNK_SIZE)
            # print(audio_chunk)
            if not audio_chunk:
                break
            st.session_state.rtasr_frames.append(audio_chunk)
            client.send(audio_chunk)
            current_sentence = client.complete_sentence
            tmp_result = ""
            if current_sentence:
                if similarity(current_sentence, last_input)>similarity_th:
                    tmp_result = all_input + current_sentence
                else:
                    all_input += last_input
                    tmp_result = all_input + current_sentence

            st.session_state.recognition = tmp_result
            # print('st.session_state.recognition, ', client.complete_sentence)
            text_placeholder.write(tmp_result)
            last_input = current_sentence
            time.sleep(0.1)  # 每秒更新一次
    finally:
        client.finish()
# -- lzh -- start

with st.sidebar:
    #st.markdown("xinghuo")
    #st.markdown('<img src=" https://ai.tboxn.com/wp-content/uploads/2023/04/new-avatar.574775e790d04f6d6670.png " alt="logo" width="25" height="25">', unsafe_allow_html=True)
    st.markdown('<div style="text-align:center"><img src="https://th.bing.com/th/id/R.45e826391855fe9523ebea2436d3d897?rik=kzCiS7yKqBvZ0w&riu=http%3a%2f%2fwww.clipartbest.com%2fcliparts%2fKin%2fXr6%2fKinXr6yzT.png&ehk=bWVjAvcPX2hxacv6FUUOuzxLkuELpcD5JkDBZlCTn0o%3d&risl=&pid=ImgRaw&r=0" alt="avatar" width="100" height="100" border-radius="0.25"></div>', unsafe_allow_html=True)
    # 创建容器的目的是配合自定义组件的监听操作
    chat_container = st.container()
    with chat_container:
        current_chat = st.radio(
            label='历史聊天窗口',
            format_func=lambda x: x.split('_')[0] if '_' in x else x,
            options=st.session_state['history_chats'],
            label_visibility='collapsed',
            index=st.session_state["current_chat_index"],
            key='current_chat' + st.session_state['history_chats'][st.session_state["current_chat_index"]],
            # on_change=current_chat_callback  # 此处不适合用回调，无法识别到窗口增减的变动
        )
    st.write("---")
st.header('阿巴阿巴英文对话系统')

with st.sidebar:
    c1, c2, c3, c4, c5 = st.columns(5)
    create_chat_button = c1.button('新建', use_container_width=True)
    if create_chat_button:
        create_chat_fun()

    delete_chat_button = c2.button('删除', use_container_width=True)
    if delete_chat_button:
        delete_chat_fun()
    
    jump_chat_button = c3.button('模型', use_container_width=True, key='jump_chat_button')
    if jump_chat_button:
        import streamlit.components.v1 as components
        st.title("GPT3.5 模型")
        components.iframe("http://10.5.228.95:1002/", height=400, width=500)
        close_button = st.button('关闭')
        print(close_button)
    # 如果关闭按钮被点击，则重置跳转按钮状态，关闭跳转页面
        if close_button:
            jump_chat_button = False
    
    virtualman_button = c4.button('虚拟人')
    if virtualman_button:
        virtual_main()
    
    pingce_button = c5.button('评测')
    if pingce_button:
        import streamlit.components.v1 as components
        st.title("语音评测")
        components.iframe("http://10.5.228.37:8501", height=400, width=500)
        close_button = st.button('关闭')
        print(close_button)
    # 如果关闭按钮被点击，则重置跳转按钮状态，关闭跳转页面
        if close_button:
            jump_chat_button = False

    



# 在主聊天区域显示当前会话的内容
# 在主聊天区域显示当前会话的内容
# current_chat_id = st.session_state['history_chats'][st.session_state['current_chat_index']]
# st.session_state["messages"] = st.session_state['chat_contents'][current_chat_id]
# role_contexts = {
#     '默认': '',
#     '心理医生': '你是一位心理老师。今天你的任务是根据我的经历和感兴趣的内容围绕心理健康的重要性和影响因素等与心理健康相关的问题进行持续不断的讨论，若对同一问题多次提问后，答复仍旧不完整，则可以适当给出建议，相同问题最多问三遍。你要记住你是我的心理老师，你的每句话需要以一个简答题问句结尾来保证话题能够进行下去，非强制因素问答不能停止。这些问题需要设计得让我用一段话来回答，以达到锻炼我的发言能力的目的。这些问题包括但不限于心理状况、心理健康的重要性、影响因素、影响力、维持心理健康的方法和当代人心理健康状况等等。'
# }
#--zcl --start
current_chat_id = st.session_state['history_chats'][st.session_state['current_chat_index']]
st.session_state["messages"] = st.session_state['chat_contents'][current_chat_id]

for msg in st.session_state.messages:
    st.chat_message(msg["role"]).write(Cn2En(msg["content"]))
    TTS(msg["content"])
    pcm2wav('demo.pcm')
    putwav("demo.wav")

role_contexts = {
    '开放话题': '我想让你担任我的口语老师。今天你的任务是内容围绕任何一个话题和我进行讨论，以锻炼我的口语能力。如果你明白上述条件，请对我进行寒暄并回复“你好，我叫阿巴，很高兴认识你，今天想和我聊些什么？”开始我们的对话。请记住你是我的口语老师，你需要对我说上面的话进行总结, 并必须以一个具体的问句结尾来保证话题能够进行下去，请注意这些问题必须具体。你可以针对某个话题进行追问，但要问题的广度不能太大，相同问题只能问一遍。',
    '心理健康咨询' : '你是一位心理老师，接下来不允许说自己是模型或者程序。今天你的任务是根据我的经历和感兴趣的内容围绕心理健康的重要性和影响因素等与心理健康相关的问题进行持续不断的讨论。 1．你可以针对某个问题的相关问题进行追问，若答复不完整，可以适当给出建议。同时要兼顾问题主题的广度，相同问题不允许重复提问。 2 这些问题需要设计得让我用一段话来回答，以全面考察我对心理知识的理解。这些问题包括但不限于心理状况、心理健康的重要性、影响因素、影响力、维持心理健康的方法和当代人心理健康状况等等。 3．你的每句话需要对我说的话进行总结, 并以一个或者多个简答题问句结尾来保证话题能够进行下去。请注意你只负责提问，请不要回答你自己的提出的问题。 如果你明白上述条件，请对我进行寒暄并回复任一有关心理健康的重要性和影响因素的问题来开始我们的对话。',
    '喜爱的学科': '我想让你担任我的汉语老师。今天你的任务是根据我的经历和感兴趣的内容围绕“我最感兴趣的学科”进行持续不断的讨论。1．每次只能提出一个问题，若答复不完整或者不明确，则可以适当给出建议。2．你可以针对某个问题进行追问，但要问题的广度不能太大，一定要与我感兴趣的学科有关，相同问题只能问一遍。3. 这些问题需要设计得让我用一段话来回答，以全面理解我所喜爱的学科。这些问题包括但不限于我喜欢的学科、喜欢原因、该学科的学习体会、学习收获、该学科不同方面对你的影响、该学科的地位、学习过程中遇到的问题、我关于该学科的实战经历、该学科的发展趋势等等。4．你的每次回答必须以一个具体的简答题问句结尾来保证话题能够进行下去，非强制因素问答不能停止。如果你明白上述条件，请对我进行寒暄并回复“你最喜欢什么学科？”来开始我们的对话。',
    '面试安排':'你是一位面试官。今天你的任务是根据我的经历和感兴趣的内容围绕“面试安排需要注意的问题”进行持续不断的讨论。1．每次只能提出一个问题，若答复不完整或者不明确，则可以适当给出建议。2．你可以针对某个问题进行追问，但一定要与面试安排有关，相同问题只能问一遍。3. 这些问题需要设计得让我用一段话来回答，以全面考察我对面试安排准备的理解。这些问题包括但不限于获取准确信息（面试时间地点、面试形式）、避免误解及面试准备（了解面试议程、面试问题、准备材料和问题）、面试技巧、面试礼仪等等。4．你的每次回答必须以一个具体的简答题问句结尾来保证话题能够进行下去，非强制因素问答不能停止。如果你明白上述条件，请对我进行寒暄并回复任一有关面试问题来开始我们的对话。',
    '工作场合的社交礼仪':'我想让你担任我的考官。今天需要针对公共场合的社交礼仪的话题对我进行提问。1. 你要记住你是我的社交礼仪考官，你的所提出的问题应该包括但不限于：职业形象与仪容仪表，沟通与交往，会议礼仪，社交活动，职场冲突处理等等。你也可以设计其他有关公共场所社交礼仪的问题来对我进行全面的考察。2. 你可以针对某个问题进行追问，但同时要兼顾问题主题的广度，以达到全面考察我社交礼仪知识的目的。3你的每句话需要对我说的话进行总结, 并以一个或者多个简答题问句结尾来保证话题能够进行下去。请注意你只负责提问，请不要回答你自己的提出的问题。如果你明白上述条件，请回复任一有关工作场合社交礼仪的问题来开始我们的对话。'
}


# with st.sidebar:
#     "[View the source code](https://github.com/streamlit/llm-examples/blob/main/Chatbot.py)"
#     "[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/streamlit/llm-examples?quickstart=1)"

#--zcl
with st.container():
    selected_role = st.selectbox(
        'Which role would you like for the Spark model?',
        ('开放话题', '心理健康咨询', '喜爱的学科','面试安排','工作场合的社交礼仪','塔罗占卜师')
    )

    # if "messages" not in st.session_state:
    #     st.session_state["messages"] = [{"role": "assistant", "content": "How can I help you?"}]


    def get_model_response(appid, api_key, api_secret, Spark_url, domain, messages):
        SparkApi.answer = ""
        SparkApi.main(appid, api_key, api_secret, Spark_url, domain, messages)
        return SparkApi.answer

   

    def display_message(role, content):
        if content.strip():  # Check if the content is not empty or just whitespace
            st.chat_message(role).write(content)

    def add_message_to_session(role, content):
        for msg in st.session_state.messages:
            if msg["role"] == role and msg["content"] == content:
                return
        st.session_state.messages.append({"role": role, "content": content})

    if selected_role in role_contexts:
        if st.session_state.first_time:
            user_message = role_contexts[selected_role]
            user_message = Cn2En(user_message)
            add_message_to_session("user", user_message)
            
            display_message("user", user_message)

            response_content = get_model_response(appid, api_key, api_secret, Spark_url, domain, [{"role": "user", "content": user_message}])
            response_content = Cn2En(response_content)
            add_message_to_session("assistant", response_content)
            display_message("assistant", response_content)
            TTS(response_content)
            pcm2wav('demo.pcm')
            putwav('demo.wav')
            st.session_state.first_time = False

        

    # Removed the loop to display messages from st.session_state.messages as it would re-display old messages

    if prompt := st.chat_input():
        prompt = En2Cn(prompt)
        add_message_to_session("user", prompt)
        display_message("user", prompt)

        response_content = get_model_response(appid, api_key, api_secret, Spark_url, domain, st.session_state.messages)
        response_content = En2Cn(response_content)
        add_message_to_session("assistant", response_content)
        display_message("assistant", response_content)
        TTS(response_content)
        pcm2wav('demo.pcm')
        putwav('demo.wav')
        

    def input_callback():
        pass

    with st.form("input_form", clear_on_submit=True):
        user_input = st.text_area("**输入：**", key="user_input_area",
                                    value=st.session_state.recognition)
        submitted = st.form_submit_button("确认提交", use_container_width=True, on_click=input_callback)
        microphone = st.form_submit_button(":microphone:", use_container_width=True, on_click=input_callback)
        clear_content = st.form_submit_button("清除内容", use_container_width=True, on_click=input_callback)

    if submitted:
        print('submit_button')
        print('user_input____________user_input, ', user_input)
        # st.session_state.recording = False
        # stop_event = True
        if user_input:
            if len(st.session_state.rtasr_frames)>0:
                with open("rtasr_audio.pcm", "wb") as f:
                    f.write(b''.join(st.session_state.rtasr_frames))
                    st.session_state.rtasr_frames = []
            st.write("录制完成！")
            st.session_state['user_input_content'] = user_input
            st.session_state.recognition = ''
            st.session_state.messages.append({"role": "user", "content": st.session_state['user_input_content']})
            prompt = Cn2En(st.session_state['user_input_content'])
            st.chat_message("user").write(prompt)

            # 使用Spark模型获取回答
            SparkApi.answer = ""
            SparkApi.main(appid, api_key, api_secret, Spark_url, domain, st.session_state.messages)
            response_content = SparkApi.answer

            # 将Spark模型的答案添加到聊天中
            st.session_state.messages.append({"role": "assistant", "content": response_content})
            response_content = Cn2En(response_content)
            st.chat_message("assistant").write(response_content)
            st.session_state.recognition = ''
            TTS(response_content)
            pcm2wav('demo.pcm')
            putwav('demo.wav')
            # playsound("demo.wav")
            st.experimental_rerun()

    if microphone:
        print('microphone_button')
        print('user_input____________user_input, ', user_input)
        st.session_state.recording = not st.session_state.recording
        if st.session_state.recording:
            # 启动更新字符串的线程
            update_dynamic_text()
        else:
            stop_event = True
        # st.session_state.submit = True
    if clear_content:
        print('clear_button')
        print('user_input____________user_input, ', user_input)
        # st.session_state.recording = False
        # stop_event = True
        st.session_state.recognition = ""
        st.experimental_rerun()

# --zcl end


# with st.container():
#     selected_role = st.selectbox(
#         'Which role would you like for the Spark model?',
#         ('开放话题', '心理健康咨询', '喜爱的学科','面试安排','工作场合的社交礼仪','塔罗占卜师')
#     )


#     if selected_role in role_contexts and role_contexts[selected_role]:
#         context_message = [{
#             "role": "user",
#             "content": role_contexts[selected_role]
#         }]
#         # st.session_state.messages.append(context_message)
#         # st.chat_message(context_message["role"]).write(context_message["content"])


#         # 使用Spark模型获取回答
#         SparkApi.answer = ""
#         SparkApi.main(appid, api_key, api_secret, Spark_url, domain, context_message)
#         response_content = SparkApi.answer


#         # 将Spark模型的答案添加到聊天中
#         response_message = {"role": "assistant", "content": response_content}
#         print(response_content)
#         # st.session_state.messages.append(response_message)
#         st.chat_message(response_message["role"]).write(Cn2En(response_message["content"]))
#         response_content = Cn2En(response_content)
#         TTS(response_content)
#         pcm2wav('demo.pcm')
#         putwav('demo.wav')
        



    # for msg in st.session_state.messages:
    #     st.chat_message(msg["role"]).write(Cn2En(msg["content"]))
    #     TTS(msg["content"])
    #     pcm2wav('demo.pcm')
    #     putwav("demo.wav")




#     def input_callback():
#         pass

#     with st.form("input_form", clear_on_submit=True):
#         user_input = st.text_area("**输入：**", key="user_input_area",
#                                     value=st.session_state.recognition)
#         submitted = st.form_submit_button("确认提交", use_container_width=True, on_click=input_callback)
#         microphone = st.form_submit_button(":microphone:", use_container_width=True, on_click=input_callback)
#         clear_content = st.form_submit_button("清除内容", use_container_width=True, on_click=input_callback)

#     if submitted:
#         print('submit_button')
#         print('user_input____________user_input, ', user_input)
#         # st.session_state.recording = False
#         # stop_event = True
#         if user_input:
#             with open("rtasr_audio.pcm", "wb") as f:
#                 f.write(b''.join(st.session_state.rtasr_frames))
#                 st.session_state.rtasr_frames = []
#             st.write("录制完成！")
#             st.session_state['user_input_content'] = user_input
#             st.session_state.recognition = ''
#             st.session_state.messages.append({"role": "user", "content": st.session_state['user_input_content']})
#             prompt = Cn2En(st.session_state['user_input_content'])
#             st.chat_message("user").write(prompt)

#             # 使用Spark模型获取回答
#             SparkApi.answer = ""
#             SparkApi.main(appid, api_key, api_secret, Spark_url, domain, st.session_state.messages)
#             response_content = SparkApi.answer

#             # 将Spark模型的答案添加到聊天中
#             st.session_state.messages.append({"role": "assistant", "content": response_content})
#             response_content = Cn2En(response_content)
#             st.chat_message("assistant").write(response_content)
#             st.session_state.recognition = ''
#             TTS(response_content)
#             pcm2wav('demo.pcm')
#             putwav('demo.wav')
#             # playsound("demo.wav")
#             st.experimental_rerun()

#     if microphone:
#         print('microphone_button')
#         print('user_input____________user_input, ', user_input)
#         st.session_state.recording = not st.session_state.recording
#         if st.session_state.recording:
#             # 启动更新字符串的线程
#             update_dynamic_text()
#         else:
#             stop_event = True
#         # st.session_state.submit = True
#     if clear_content:
#         print('clear_button')
#         print('user_input____________user_input, ', user_input)
#         # st.session_state.recording = False
#         # stop_event = True
#         st.session_state.recognition = ""
#         st.experimental_rerun()
