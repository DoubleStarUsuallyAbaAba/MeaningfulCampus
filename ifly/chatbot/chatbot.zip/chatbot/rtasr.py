# -*- encoding:utf-8 -*-
import hashlib
import hmac
import base64
from socket import *
import json, time, threading
from websocket import create_connection
import websocket
from urllib.parse import quote
import pyaudio

# reload(sys)
# sys.setdefaultencoding("utf8")

# 设置录音参数
SAMPLE_RATE = 16000
CHUNK_SIZE = 1280
FORMAT = pyaudio.paInt16
CHANNELS = 1

app_id = "2a078fda"
api_key = "811accaa8825178c1531e23dfc0c335f"

class RTASR_Client():
    def __init__(self):
        base_url = "ws://rtasr.xfyun.cn/v1/ws"
        ts = str(int(time.time()))
        tt = (app_id + ts).encode('utf-8')
        md5 = hashlib.md5()
        md5.update(tt)
        baseString = md5.hexdigest()
        baseString = bytes(baseString, encoding='utf-8')

        apiKey = api_key.encode('utf-8')
        transStrategy = 2
        signa = hmac.new(apiKey, baseString, hashlib.sha1).digest()
        signa = base64.b64encode(signa)
        signa = str(signa, 'utf-8')
        self.end_tag = "{\"end\": true}"
        self.complete_sentence = ""
        self.ws = create_connection(base_url + "?appid=" + app_id + "&ts=" + ts + "&signa=" + quote(signa))
        self.trecv = threading.Thread(target=self.recv)
        self.trecv.start()

    def send(self, audio_chunk):
        if audio_chunk:
            self.ws.send(audio_chunk)
        time.sleep(0.04)

    def recv(self):
        try:
            while self.ws.connected:
                result = str(self.ws.recv())
                if len(result) == 0:
                    # print("receive result end")
                    break
                result_dict = json.loads(result)
                # 解析结果
                if result_dict["action"] == "started":
                    pass
                    # print("handshake success, result: " + result)

                if result_dict["action"] == "result":
                    rtasr_result = json.loads(result_dict["data"])
                    # result_2 = json.loads(result_1["cn"])
                    # result_3 = json.loads(result_2["st"])
                    # result_4 = json.loads(result_3["rt"])

                    # print("rtasr result: ", rtasr_result)

                    # Extract "w" fields and form a complete sentence
                    sentence_words = []
                    if 'seg_id' in rtasr_result:
                        for segment in rtasr_result["cn"]["st"]["rt"]:
                            for word_info in segment["ws"]:
                                word = word_info["cw"][0]["w"]
                                sentence_words.append(word)
                        self.complete_sentence = "".join(sentence_words)
                        print(self.complete_sentence)
                    else:
                        print("rtasr result: ", rtasr_result)


                if result_dict["action"] == "error":
                    # print("rtasr error: " + result)
                    self.ws.close()
                    return
        except websocket.WebSocketConnectionClosedException:
            print("receive result end")

    def close(self):
        self.ws.close()
        # print("connection closed")

    def finish(self):
        self.ws.send(bytes(self.end_tag.encode('utf-8')))
        # print("send end tag success")



if __name__ == '__main__':

    client = RTASR_Client()
    audio = pyaudio.PyAudio()
    stream = audio.open(format=FORMAT, channels=CHANNELS, rate=SAMPLE_RATE, input=True, frames_per_buffer=CHUNK_SIZE)

    try:
        while True:
            audio_chunk = stream.read(CHUNK_SIZE)
            # print(audio_chunk)
            if not audio_chunk:
                break
            client.send(audio_chunk)
    finally:
        client.finish()
