import streamlit as st
import SparkApi
from helper import pcm2wav
from tts import TTS
from helper import putwav
from playsound import playsound
import threading
import os

import cv2
import requests
import json
import base64
import hashlib
import time
from urllib.parse import urlencode
import hmac
from datetime import datetime
from wsgiref.handlers import format_date_time
from time import mktime
from ws4py.client.threadedclient import WebSocketClient
import logging
import threading
import multiprocessing

def chatworker():
    pass

def ttsworker(audio_path):
    audio_name = audio_path.split('.')[0]
    pcm_path = audio_name + '.pcm'

def get_model_content():
    return st.session_state.messages[0]["content"]


# 以下密钥信息从控制台获取，这里仅为示例，你需要使用真实的密钥
appid = "e97d3136"
api_secret = "MDExMGZmZjFjMzRhOTkzNzczMGEyMzgw"
api_key = "b25338415789cf13a0091d64a1b3381e"
domain = "generalv2"
Spark_url = "ws://spark-api.xf-yun.com/v2.1/chat"
text = []
if 'history_chats' not in st.session_state:
    st.session_state['history_chats'] = ["Chat1"]
if 'current_chat_index' not in st.session_state:
    st.session_state['current_chat_index'] = 0
if 'next_chat_number' not in st.session_state:
    st.session_state['next_chat_number'] = 2
if 'chat_contents' not in st.session_state:
    st.session_state['chat_contents'] = {"Chat1": []}
if 'messages' not in st.session_state:
    st.session_state['messages'] = []


def create_chat_fun():
    # 保存当前会话的内容
    current_chat_id = st.session_state['history_chats'][st.session_state['current_chat_index']]
    st.session_state['chat_contents'][current_chat_id] = st.session_state["messages"]
    
    # 创建新的会话ID，如Chat2, Chat3等
    new_chat = f"Chat{st.session_state['next_chat_number']}"
    st.session_state['history_chats'].append(new_chat)
    st.session_state['chat_contents'][new_chat] = []  # 初始化新聊天的内容
    st.session_state['current_chat_index'] = len(st.session_state['history_chats']) - 1
    st.session_state['next_chat_number'] += 1

    st.experimental_rerun()  # 重新运行以刷新侧边栏和主内容

def delete_chat_fun():
    # 如果没有其他聊天，就什么也不做
    if len(st.session_state['history_chats']) <= 1:
        return
    
    # 删除当前聊天
    del_chat = st.session_state['history_chats'][st.session_state['current_chat_index']]
    del st.session_state['chat_contents'][del_chat]
    st.session_state['history_chats'].remove(del_chat)

    # 更新当前聊天索引
    if st.session_state['current_chat_index'] >= len(st.session_state['history_chats']):
        st.session_state['current_chat_index'] = len(st.session_state['history_chats']) - 1

    st.experimental_rerun()  # 重新运行以刷新侧边栏和主内容
with st.sidebar:
    st.markdown("# 🤖 聊天窗口")
    chat_container = st.container()
    with chat_container:
        current_chat = st.radio(
            label='历史聊天窗口',
            options=st.session_state['history_chats'],
            index=st.session_state['current_chat_index']
        )

        st.session_state['current_chat_index'] = st.session_state['history_chats'].index(current_chat)
    st.write("---")

with st.sidebar:
    c1, c2, c3, c4 = st.columns(4)
    create_chat_button = c1.button('新建', use_container_width=True)
    if create_chat_button:
        create_chat_fun()

    delete_chat_button = c2.button('删除', use_container_width=True)
    if delete_chat_button:
        delete_chat_fun()
    
    jump_chat_button = c3.button('模型', use_container_width=True, key='jump_chat_button')
    if jump_chat_button:
        import streamlit.components.v1 as components
        st.title("Embed external website")
        components.iframe("http://10.5.228.95:1002/", height=400, width=500)
        close_button = st.button('关闭跳转页面')
        print(close_button)
    # 如果关闭按钮被点击，则重置跳转按钮状态，关闭跳转页面
        if close_button:
            jump_chat_button = False
    
    virtualman_button = c4.button('虚拟人')
    


# 在主聊天区域显示当前会话的内容
# 在主聊天区域显示当前会话的内容
current_chat_id = st.session_state['history_chats'][st.session_state['current_chat_index']]
st.session_state["messages"] = st.session_state['chat_contents'][current_chat_id]
role_contexts = {
    '默认': '',
    '心理医生': '你是一位心理老师。今天你的任务是根据我的经历和感兴趣的内容围绕心理健康的重要性和影响因素等与心理健康相关的问题进行持续不断的讨论，若对同一问题多次提问后，答复仍旧不完整，则可以适当给出建议，相同问题最多问三遍。你要记住你是我的心理老师，你的每句话需要以一个简答题问句结尾来保证话题能够进行下去，非强制因素问答不能停止。这些问题需要设计得让我用一段话来回答，以达到锻炼我的发言能力的目的。这些问题包括但不限于心理状况、心理健康的重要性、影响因素、影响力、维持心理健康的方法和当代人心理健康状况等等。'
}



# with st.sidebar:
#     "[View the source code](https://github.com/streamlit/llm-examples/blob/main/Chatbot.py)"
#     "[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/streamlit/llm-examples?quickstart=1)"


with st.container():
    selected_role = st.selectbox(
        'Which role would you like for the Spark model?',
        ('默认', '心理医生', 'Other')
    )
    # st.title("💬 心理医生")
    # audio_file = open('tttt.ogg', 'rb')
    # audio_bytes = audio_file.read()


    # # 使用st.audio函数播放音频
    # st.audio(audio_bytes, format='audio/ogg')


    # if "messages" not in st.session_state:
    #     st.session_state["messages"] = [{"role": "assistant", "content": "How can I help you?"}]


    if selected_role in role_contexts and role_contexts[selected_role]:
        context_message = [{
            "role": "user",
            "content": role_contexts[selected_role]
        }]
        # st.session_state.messages.append(context_message)
        # st.chat_message(context_message["role"]).write(context_message["content"])


        # 使用Spark模型获取回答
        SparkApi.answer = ""
        SparkApi.main(appid, api_key, api_secret, Spark_url, domain, context_message)
        response_content = SparkApi.answer


        # 将Spark模型的答案添加到聊天中
        response_message = {"role": "assistant", "content": response_content}
        print(response_content)
        # st.session_state.messages.append(response_message)
        st.chat_message(response_message["role"]).write(response_message["content"])
        TTS(response_content)
        pcm2wav('demo.pcm')
        putwav('demo.wav')
        



    for msg in st.session_state.messages:
        st.chat_message(msg["role"]).write(msg["content"])
        TTS(msg["content"])
        pcm2wav('demo.pcm')
        putwav("demo.wav")

    
    if prompt := st.chat_input():
        st.session_state.messages.append({"role": "user", "content": prompt})
        st.chat_message("user").write(prompt)


        # 使用Spark模型获取回答
        SparkApi.answer = ""
        SparkApi.main(appid, api_key, api_secret, Spark_url, domain, st.session_state.messages)
        response_content = SparkApi.answer


        # 将Spark模型的答案添加到聊天中
        st.session_state.messages.append({"role": "assistant", "content": response_content})
        st.chat_message("assistant").write(response_content)
        TTS(response_content)
        pcm2wav('demo.pcm')
        putwav('demo.wav')
        # playsound("demo.wav")
    
if virtualman_button:
    #!/usr/bin/env python3
    # -*- coding: utf-8 -*-
    # @Author : iflytek
    import cv2
    import requests
    import json
    import base64
    import hashlib
    import time
    from urllib.parse import urlencode
    import hmac
    from datetime import datetime
    from wsgiref.handlers import format_date_time
    from time import mktime
    from ws4py.client.threadedclient import WebSocketClient
    import logging
    import threading
    import multiprocessing
    import streamlit as st
    from PIL import Image


    logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

    ################init 参数######################
    HOST = "vms.cn-huadong-1.xf-yun.com"
    # 音频驱动参数
    STATUS_FIRST_FRAME = 0  # 第一帧的标识
    STATUS_CONTINUE_FRAME = 1  # 中间帧标识
    STATUS_LAST_FRAME = 2  # 最后一帧的标识
    # 用户参数，相关参数注意修改

    API_SECRET = "YTk4ZTM2NDA3NzVkNDMwYTk3MDdmNThi"
    APP_ID = "920d8c8c"
    API_KEY = "1612233a7b8501aee6b8744e07761981"
    ###############################################


    class RequestParam(object):

        def __init__(self):
            self.host = HOST
            self.app_id = APP_ID
            self.api_key = API_KEY
            self.api_secret = API_SECRET
        # 生成鉴权的url
        def assemble_auth_url(self, path, method='POST', schema='http'):
            params = self.assemble_auth_params(path, method)
            # 请求地址
            request_url = "%s://"%schema + self.host + path
            # 拼接请求地址和鉴权参数，生成带鉴权参数的url
            auth_url = request_url + "?" + urlencode(params)
            return auth_url

        # 生成鉴权的参数
        def assemble_auth_params(self, path, method):
            # 生成RFC1123格式的时间戳
            format_date = format_date_time(mktime(datetime.now().timetuple()))
            # 拼接字符串
            signature_origin = "host: " + self.host + "\n"
            signature_origin += "date: " + format_date + "\n"
            signature_origin += method+ " " + path + " HTTP/1.1"
            # 进行hmac-sha256加密
            signature_sha = hmac.new(self.api_secret.encode('utf-8'), signature_origin.encode('utf-8'),
                                    digestmod=hashlib.sha256).digest()
            signature_sha = base64.b64encode(signature_sha).decode(encoding='utf-8')
            # 构建请求参数
            authorization_origin = 'api_key="%s", algorithm="%s", headers="%s", signature="%s"' % (
                self.api_key, "hmac-sha256", "host date request-line", signature_sha)
            # 将请求参数使用base64编码
            authorization = base64.b64encode(authorization_origin.encode('utf-8')).decode(encoding='utf-8')
            # 将请求的鉴权参数组合为字典
            params = {
                "host": self.host,
                "date": format_date,
                "authorization": authorization
            }
            return params


    class VmsApi(RequestParam):
        # 接口data请求参数，字段具体含义见官网文档
        # 启动
        def start(self, start_url):
            data = {
                "header": {
                    "app_id": self.app_id,
                    "uid": ""
                },
                "parameter": {
                    "vmr": {
                        "stream": {
                            "protocol": "rtmp"
                        },
                        "avatar_id": "110278006",
                        "width": 640,
                        "height": 360
                    }
                }
            }
            url_data = self.get_url_data(start_url, data)
            session = ''
            if url_data:
                session = url_data.get('header', {}).get('session', '')
                stream_url = url_data.get('header', {}).get('stream_url', '拉流地址获取失败')
                print("拉流地址：%s" %stream_url)
                
            return session, stream_url

        # 心跳
        def ping(self, ping_url, session):
            data = {
                    "header": {
                        "app_id": self.app_id,
                        "uid":"",
                        "session": session
                    }
                }
            self.get_url_data(ping_url, data)

        # 停止
        def stop(self, stop_url, session):
            data = {
                "header": {
                    "app_id": self.app_id,
                    "session": session,
                    "uid":""
                }
            }
            self.get_url_data(stop_url, data)

        # 文本驱动
        def text_ctrl(self, text_url, session, text):
            # 合成文本
            encode_str = base64.encodebytes(text.encode("UTF8"))
            txt = encode_str.decode()
            data = {
                "header": {
                    "app_id": self.app_id,
                    "session": session,
                    "uid": ""
                },
                "parameter": {
                    "tts": {
                        "vcn": "x3_qianxue",
                        "speed": 50,
                        "pitch": 50,
                        "volume": 50
                    }
                },
                "payload": {
                    "text": {
                        "encoding": "utf8",
                        "status": 3,
                        "text": txt
                    },
                    "ctrl_w": {
                        "encoding": "utf8",
                        "format": "json",
                        "status": 3,
                        #"text": ""
                    }
                }
            }
            self.get_url_data(text_url, data)
            print("请求参数：",json.dumps(data))

        # 音频驱动
        def audio_ctrl(self, audio_url, session, audio_file):
            auth_audio_url = self.assemble_auth_url(audio_url, 'GET', 'ws')
            ws = AudioCtrl(auth_audio_url, session, audio_file)
            ws.connect()
            ws.run_forever()

        def get_url_data(self, url, data):
            auth_url = self.assemble_auth_url(url)
            print("示例url:",auth_url)
            headers = {'Content-Type': 'application/json'}
            try:
                result = requests.post(url=auth_url, headers=headers, data=json.dumps(data))
                result = json.loads(result.text)
                print("response:",json.dumps(result))
                code = result.get('header', {}).get('code')
                if code == 0:
                    logging.info("%s 接口调用成功" % url)
                    return result
                else:
                    logging.error("%s 接口调用失败，错误码:%s" % (url, code))
                    return {}
            except Exception as e:
                logging.error("%s 接口调用异常，错误详情:%s" %(url, e) )
                return {}


    # websocket 音频驱动
    class AudioCtrl(WebSocketClient):

        def __init__(self, url, session, file_path):
            super().__init__(url)
            self.file_path = file_path
            self.session = session
            self.app_id = APP_ID

        # 收到websocket消息的处理
        def received_message(self, message):
            message = message.__str__()
            try:
                res = json.loads(message)
                print("response:",json.dumps(res))
                # 音频驱动接口返回状态码
                code = res.get('header', {}).get('code')
                # 状态码为0，音频驱动接口调用成功
                if code == 0:
                    logging.info("音频驱动接口调用成功")
                # 状态码非0，音频驱动接口调用失败, 相关错误码参考官网文档
                else:
                    logging.info("音频驱动接口调用失败，返回状态码: %s" % code)
            except Exception as e:
                logging.info("音频驱动接口调用失败，错误详情:%s" % e)

        # 收到websocket错误的处理
        def on_error(self, error):
            logging.error(error)

        # 收到websocket关闭的处理
        def closed(self, code, reason=None):
            logging.info('音频驱动：websocket关闭')

        # 收到websocket连接建立的处理
        def opened(self):
            logging.info('音频驱动：websocket连接建立')
            frame_size = 1280  # 每一帧音频大小
            interval = 0.04  # 发送音频间隔(单位:s)
            status = STATUS_FIRST_FRAME  # 音频的状态信息，标识音频是第一帧，还是中间帧、最后一帧
            count = 1
            with open(self.file_path, 'rb') as file:
                while True:
                    buffer = file.read(frame_size)
                    if len(buffer) < frame_size:
                        status = STATUS_LAST_FRAME
                    # 第一帧处理
                    if status == STATUS_FIRST_FRAME:
                        self.send_frame(status, buffer, count)
                        status = STATUS_CONTINUE_FRAME
                    # 中间帧处理
                    elif status == STATUS_CONTINUE_FRAME:
                        self.send_frame(status, buffer, count)

                    # 最后一帧处理
                    elif status == STATUS_LAST_FRAME:
                        self.send_frame(status, buffer, count)
                        break
                    count += 1
                    # 音频采样间隔
                    time.sleep(interval)

        # 发送音频
        def send_frame(self, status, audio_buffer, seq):
            data = {
                "header": {
                    "app_id": self.app_id,
                    "session": self.session,
                    "status": status,
                    "uid":""
                },
                "payload": {
                    "audio": {
                        "encoding": "raw",
                        "sample_rate": 16000,
                        "status": status,
                        "seq": seq,
                        "audio": base64.encodebytes(audio_buffer).decode("utf-8")
                    }
                }
            }
            json_data = json.dumps(data)
            print("请求参数：",json_data)
            self.send(json_data)




    if __name__ == "__main__":
        vms = VmsApi()
        start_url = "/v1/private/vms2d_start"
        print("启动")
        list = []
        list = vms.start(start_url)
        session = list[0]
        stream_url = list[1]
        
        def block1():
            if session:
                
                # 文本驱动，自定义文本内容
                #time.sleep(30)
                print("\n文本驱动")
                text = "Certainly! Here's an English text snippet for you:The universe is a vast and mysterious expanse, filled with countless stars, galaxies, and cosmic wonders. From the tiniest particles to the grandest celestial bodies, there is an intricate dance of forces that shapes the cosmos. Scientists and astronomers dedicate their lives to unraveling the secrets of the universe, seeking to understand its origins, evolution, and ultimate fate. Through observation and exploration, humanity continues to uncover the beauty and complexity of the cosmos, reminding us of our small yet significant place in the grand tapestry of existence."
                text_url = "/v1/private/vms2d_ctrl"
                vms.text_ctrl(text_url, session, text)
                """
                # 音频驱动
                time.sleep(10)
                print("\n音频驱动")
                audio_url = "/v1/private/vms2d_audio_ctrl"
                # 自定义本地音频路径
                audio_file = "./tts.mp3"
                vms.audio_ctrl(audio_url, session, audio_file)
            
                # 心跳
                time.sleep(60)
                print("\n心跳")
                ping_url = "/v1/private/vms2d_ping"
                vms.ping(ping_url, session)

                # 停止
                time.sleep(10)
                print("\n停止")
                stop_url = "/v1/private/vms2d_stop"
                vms.stop(stop_url, session)
                """
        def block2():
            # 使用OpenCV捕获流
            cap = cv2.VideoCapture(stream_url)
            while True:
                # 读取帧
                ret, frame = cap.read()
                if ret:
                    resized_frame = cv2.resize(frame, (400, 700))
                    # 在窗口中显示调整后的帧
                    cv2.imshow('Resized Frame', resized_frame)
                    
                if not ret:
                    print("Failed to retrieve frame")
                    break

                # 显示帧
                #cv2.imshow('RTMP Stream', frame)

                # 按 'q' 键退出
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
            cap.release()
            cv2.destroyAllWindows()
            
        thread1 = threading.Thread(target=block1)
        thread2 = threading.Thread(target=block2)

        # 启动线程
        thread1.start()
        thread2.start()
        
        # 等待线程结束
        thread1.join()
        thread2.join()
        """
        process1 = multiprocessing.Process(target=block1)
        process2 = multiprocessing.Process(target=block2)

        # 启动进程
        process1.start()
        process2.start()

        # 等待进程结束
        process1.join()
        process2.join()
        """
        print("结束")