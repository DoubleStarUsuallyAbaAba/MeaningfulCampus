import streamlit as st
import SparkApi
import time
import pyaudio
import threading
from rtasr import RTASR_Client
from difflib import SequenceMatcher
# 以下密钥信息从控制台获取，这里仅为示例，你需要使用真实的密钥
appid = "e97d3136"
api_secret = "MDExMGZmZjFjMzRhOTkzNzczMGEyMzgw"
api_key = "b25338415789cf13a0091d64a1b3381e"
domain = "generalv2"
Spark_url = "ws://spark-api.xf-yun.com/v2.1/chat"
# 初始化标点符号列表和存储数据的变量
stop_words = [',' , '.', '?' , '!' , ';', '，' , '。', '？' , '：', '！' , '；']  # 常见的标点符号
similarity_th = 0.4
# 创建一个Event对象
stop_event = False

if "initial_settings" not in st.session_state:
    st.session_state["messages"] = [{"role": "assistant", "content": "How can I help you?"}]
    st.session_state.recognition = ""
    st.session_state.rtasr_frames = []
    st.session_state.recording = False
    st.session_state.submit = False
    # 设置完成
    st.session_state["initial_settings"] = True
with st.sidebar:
    "[View the source code](https://github.com/streamlit/llm-examples/blob/main/Chatbot.py)"
    "[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/streamlit/llm-examples?quickstart=1)"

st.title("💬 Chatbot")

for msg in st.session_state.messages:
    st.chat_message(msg["role"]).write(msg["content"])

# 更新字符串的函数
def update_dynamic_text():
    # 设置录音参数
    SAMPLE_RATE = 16000
    CHUNK_SIZE = 1280
    FORMAT = pyaudio.paInt16
    CHANNELS = 1

    client = RTASR_Client()
    audio = pyaudio.PyAudio()
    stream = audio.open(format=FORMAT, channels=CHANNELS, rate=SAMPLE_RATE, input=True, frames_per_buffer=CHUNK_SIZE)

    # 定义函数来计算字符串的重合度
    def similarity(a, b):
        return SequenceMatcher(None, a, b).ratio()

    try:
        text_placeholder = st.empty()
        all_input = ""
        last_input = ""
        while not stop_event:
            audio_chunk = stream.read(CHUNK_SIZE)
            # print(audio_chunk)
            if not audio_chunk:
                break
            st.session_state.rtasr_frames.append(audio_chunk)
            client.send(audio_chunk)
            current_sentence = client.complete_sentence
            tmp_result = ""
            if current_sentence:
                if similarity(current_sentence, last_input)>similarity_th:
                    tmp_result = all_input + current_sentence
                else:
                    all_input += last_input
                    tmp_result = all_input + current_sentence

            st.session_state.recognition = tmp_result
            # print('st.session_state.recognition, ', client.complete_sentence)
            text_placeholder.write(tmp_result)
            last_input = current_sentence
            time.sleep(0.1)  # 每秒更新一次
    finally:
        client.finish()

# 添加一个空的占位 div，用于将控件固定在底部
# st.markdown('<div style="height: 30vh;"></div>', unsafe_allow_html=True)
# print('in button_a st.session_state.recognition, ', st.session_state.recognition)
def input_callback():
    pass

with st.form("input_form", clear_on_submit=True):
    user_input = st.text_area("**输入：**", key="user_input_area",
                                value=st.session_state.recognition)
    submitted = st.form_submit_button("确认提交", use_container_width=True, on_click=input_callback)
    microphone = st.form_submit_button(":microphone:", use_container_width=True, on_click=input_callback)
    clear_content = st.form_submit_button("清除内容", use_container_width=True, on_click=input_callback)

if submitted:
    print('submit_button')
    print('user_input____________user_input, ', user_input)
    # st.session_state.recording = False
    # stop_event = True
    if user_input:
        with open("rtasr_audio.pcm", "wb") as f:
            f.write(b''.join(st.session_state.rtasr_frames))
            st.session_state.rtasr_frames = []
        st.write("录制完成！")
        st.session_state['user_input_content'] = user_input
        st.session_state.recognition = ''
        st.session_state.messages.append({"role": "user", "content": st.session_state['user_input_content']})
        st.chat_message("user").write(st.session_state['user_input_content'])

        # 使用Spark模型获取回答
        SparkApi.answer = ""
        SparkApi.main(appid, api_key, api_secret, Spark_url, domain, st.session_state.messages)
        response_content = SparkApi.answer

        # 将Spark模型的答案添加到聊天中
        st.session_state.messages.append({"role": "assistant", "content": response_content})
        st.chat_message("assistant").write(response_content)
        st.session_state.recognition = ''
        st.experimental_rerun()

if microphone:
    print('microphone_button')
    print('user_input____________user_input, ', user_input)
    st.session_state.recording = not st.session_state.recording
    if st.session_state.recording:
        # 启动更新字符串的线程
        update_dynamic_text()
    else:
        stop_event = True
    # st.session_state.submit = True
if clear_content:
    print('clear_button')
    print('user_input____________user_input, ', user_input)
    # st.session_state.recording = False
    # stop_event = True
    st.session_state.recognition = ""
    st.experimental_rerun()
