import streamlit as st
import SparkApi


#检查是否初始化,没有初始化在此初始化
if "initial_settings" not in st.session_state:
    # 历史聊天窗口
    st.session_state["path"] = 'history_chats_file'
    st.session_state['history_chats'] = ''
    # ss参数初始化
    st.session_state['delete_dict'] = {}
    st.session_state['delete_count'] = 0
    st.session_state['voice_flag'] = ''
    st.session_state['user_voice_value'] = ''
    st.session_state['error_info'] = ''
    st.session_state["current_chat_index"] = 0
    st.session_state['user_input_content'] = ''

def create_chat_fun():
    pass

def delete_chat_fun():
    pass


with st.sidebar:
    st.markdown("# 🤖 聊天窗口")
    # 创建容器的目的是配合自定义组件的监听操作
    chat_container = st.container()
    with chat_container:
        current_chat = st.radio(
            label='历史聊天窗口',
            format_func=lambda x: x.split('_')[0] if '_' in x else x,
            options=st.session_state['history_chats'],
            label_visibility='collapsed',
            # index=st.session_state["current_chat_index"],
            # key='current_chat' + st.session_state['history_chats'][st.session_state["current_chat_index"]],
            # on_change=current_chat_callback  # 此处不适合用回调，无法识别到窗口增减的变动
        )
    st.write("---")

with st.sidebar:
    c1, c2, c3 = st.columns(3)
    create_chat_button = c1.button('新建', use_container_width=True, key='create_chat_button')
    if create_chat_button:
        create_chat_fun()
        st.experimental_rerun()

    delete_chat_button = c2.button('删除', use_container_width=True, key='delete_chat_button')
    if delete_chat_button:
        delete_chat_fun()
        st.experimental_rerun()
    
    jump_chat_button = c3.button('跳转', use_container_width=True, key='jump_chat_button')
    if jump_chat_button:
        left_col, right_col = st.columns(2)  # 分成两列
        with left_col:
            st.write("模型1")
        
        with right_col:
            st.write("模型2")
        import streamlit.components.v1 as components
        st.title("GPT-3.5 Model")
        components.iframe("http://localhost:8501", height=400, width=600)
        close_button = st.button('关闭跳转页面')
        print(close_button)
    # 如果关闭按钮被点击，则重置跳转按钮状态，关闭跳转页面
        if close_button:
            jump_chat_button = False
    
    # openai_api_key = st.text_input("OpenAI API Key", key="chatbot_api_key", type="password")
    # "[Get an OpenAI API key](https://platform.openai.com/account/api-keys)"
    # "[View the source code](https://github.com/streamlit/llm-examples/blob/main/Chatbot.py)"
    # "[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/streamlit/llm-examples?quickstart=1)"

# 以下密钥信息从控制台获取，这里仅为示例，你需要使用真实的密钥

appid = "e97d3136"
api_secret = "MDExMGZmZjFjMzRhOTkzNzczMGEyMzgw"
api_key = "b25338415789cf13a0091d64a1b3381e"
domain = "generalv2"
Spark_url = "ws://spark-api.xf-yun.com/v2.1/chat"
text = []


# with st.container():
#     st.title("💬 Chatbot")

#     if "messages" not in st.session_state:
#         st.session_state["messages"] = [{"role": "assistant", "content": "How can I help you?"}]

#     for msg in st.session_state.messages:
#         st.chat_message(msg["role"]).write(msg["content"])

#     if prompt := st.chat_input("请输入消息："):
#         st.session_state.messages.append({"role": "user", "content": prompt})
#         st.chat_message("user").write(prompt)

#         # 使用Spark模型获取回答
#         SparkApi.answer = ""
#         SparkApi.main(appid, api_key, api_secret, Spark_url, domain, st.session_state.messages)
#         response_content = SparkApi.answer

#         # 将Spark模型的答案添加到聊天中
#         st.session_state.messages.append({"role": "assistant", "content": response_content})
#         st.chat_message("assistant").write(response_content)

    
#         st.chat_input('i love you')
with st.container():
    st.title("💬 喜爱的学科")

    edu_prompt = "我想让你担任我的汉语老师。今天你的任务是根据我的技能、兴趣和经验和我围绕最感兴趣的学科进行讨论。你要记住你是我的汉语练习老师，你的每句话需要以一个或者多个简答题问句结尾来保证话题能够进行下去。这些问题需要设计得让我用一段话来回答，以达到锻炼我的汉语能力的目的。这些问题包括但不限于学科的喜爱原因，学习方法，经历，收获，就业趋势等等。如果你明白上述条件，请回复：'你最喜欢的科目是什么？'来开始我们的对话。"
    first_session_state_messages = [{"role": "user", "content": edu_prompt}]
    SparkApi.answer = ""
    SparkApi.main(appid, api_key, api_secret, Spark_url, domain, first_session_state_messages)
    response_content = SparkApi.answer
    # st.chat_message("assistant").write(response_content)
    print(response_content)

    if "messages" not in st.session_state:
        st.session_state["messages"] = [{"role": "assistant", "content": response_content}]
    

    for msg in st.session_state.messages:
        st.chat_message(msg["role"]).write(msg["content"])


    if prompt := st.chat_input("请输入消息："):
        st.session_state.messages.append({"role": "user", "content": prompt})
        st.chat_message("user").write(prompt)

        # 使用Spark模型获取回答
        SparkApi.answer = ""
        SparkApi.main(appid, api_key, api_secret, Spark_url, domain, st.session_state.messages)
        response_content = SparkApi.answer

        # 将Spark模型的答案添加到聊天中
        st.session_state.messages.append({"role": "assistant", "content": response_content})
        st.chat_message("assistant").write(response_content)
        
        audio_file = open('demo.wav', 'rb')
        audio_bytes = audio_file.read()


        # # 使用st.audio函数播放音频
        st.audio(audio_bytes, format='audio/ogg',auto_play=True, controls=False)